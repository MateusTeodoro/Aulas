package exercicioequação;

public class Equacao 
{
    private int a, b, c;
    private double delta, raiz1, raiz2, x, y;

    public Equacao(){}
    
    public Equacao(int a, int b, int c)
    {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public void calculaDelta()
    {
        this.delta = (b * b) - 4 * a * c;
    }
    
    public void calculaRaiz()
    {
        this.raiz1 = (-b + Math.sqrt(delta)) / (2 * a);
        this.raiz2 = (-b - Math.sqrt(delta)) / (2 * a);
    }
    
    public void calculaVertice()
    {
        this.x = -b / (2.0 * a);
        this.y = -delta / (4.0 * a);
    }
    
    public void mostraEquacao()
    {
        if (delta < 0)
        {
            System.out.println("Nao existem raizes reais. \n");
        }
        
        else if (delta == 0)
        {
            System.out.println("Existe apenas uma raiz real: " + this.raiz1 + "\n");
        }
        
        else if (delta > 0)
        {
            System.out.println("As raizes reais sao: " + this.raiz1 + " e " + this.raiz2 + "\n");
        }
        
        System.out.println("O valor do vertice X e: " + this.x + "\n");
        System.out.println("O valor do vertice Y e: " + this.y + "\n");
    }
}
