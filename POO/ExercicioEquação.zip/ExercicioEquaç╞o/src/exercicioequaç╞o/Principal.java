package exercicioequação;
import java.util.Scanner;


public class Principal 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();
        
        Equacao polinomio = new Equacao(a, b, c);
        polinomio.calculaDelta();
        polinomio.calculaRaiz();
        polinomio.calculaVertice();
        polinomio.mostraEquacao();
    }
}
